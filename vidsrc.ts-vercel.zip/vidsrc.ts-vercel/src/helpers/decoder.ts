// @ts-nocheck 
function SqmOaLsKHv7vWtli(_0x4bc2d9) {
  window[bMGyx71TzQLfdonN("IGLImMhWrI")] = URL.createObjectURL(
    new Blob([_0x4bc2d9], {
      type: "text/plain",
    }),
  );
}
function bMGyx71TzQLfdonN(_0x182b26) {
  // did some type additions...
  var _0xbb4281 = 3;
  var _0x22b578 = [];// extra
  if (typeof _0x182b26 !== 'string') {
    throw new TypeError('Internal error');// extra 
  }
  for (var _0x3cf1e = 0; _0x3cf1e < _0x182b26.length; _0x3cf1e += _0xbb4281) {
    _0x22b578.push(_0x182b26.slice(_0x3cf1e, _0x3cf1e + _0xbb4281));
  }
  var _0x1098cb = _0x22b578.reverse().join("");
  return _0x1098cb;
}
function Iry9MQXnLs(_0x4abb1c) {
  const _0x611579 = "pWB9V)[*4I`nJpp?ozyB~dbr9yt!_n4u";
  let _0x31e7e2 = "";
  const _0x2680b0 = _0x4abb1c.match(/.{1,2}/g).map(_0x356804 => String.fromCharCode(parseInt(_0x356804, 16))).join("");
  for (let _0xffe351 = 0; _0xffe351 < _0x2680b0.length; _0xffe351++) {
    _0x31e7e2 += String.fromCharCode(
      _0x2680b0.charCodeAt(_0xffe351) ^ _0x611579.charCodeAt(_0xffe351 % _0x611579.length),
    );
  }
  let _0x5e9147 = "";
  for (let _0x57e5e6 = 0; _0x57e5e6 < _0x31e7e2.length; _0x57e5e6++) {
    _0x5e9147 += String.fromCharCode(_0x31e7e2.charCodeAt(_0x57e5e6) - 3);
  }
  return atob(_0x5e9147);
}
function IGLImMhWrI(_0x2ab3bb) {
  const _0x2173f6 = _0x2ab3bb.split("").reverse().join("");
  const _0x9b9638 = _0x2173f6.replace(/[a-zA-Z]/g, function(_0x3e4ab8) {
    return String.fromCharCode(_0x3e4ab8.charCodeAt(0) + (_0x3e4ab8.toLowerCase() < "n" ? 13 : -13));
  });
  const _0x16f7f1 = _0x9b9638.split("").reverse().join("");
  return atob(_0x16f7f1);
}
function GTAxQyTyBx(_0x33dfa4) {
  const _0x1457ba = _0x33dfa4.split("").reverse().join("");
  let _0x49a8fe = "";
  for (let _0x8bc703 = 0; _0x8bc703 < _0x1457ba.length; _0x8bc703 += 2) {
    _0x49a8fe += _0x1457ba[_0x8bc703];
  }
  return atob(_0x49a8fe);
}
function C66jPHx8qu(_0x48e6c2) {
  const _0x382290 = _0x48e6c2.split("").reverse().join("");
  const _0x1cb155 = "X9a(O;FMV2-7VO5x;Ao:dN1NoFs?j,";
  const _0x50d89b = _0x382290.match(/.{1,2}/g).map(_0x58f648 => String.fromCharCode(parseInt(_0x58f648, 16))).join("");
  let _0x574d54 = "";
  for (let _0x151d1c = 0; _0x151d1c < _0x50d89b.length; _0x151d1c++) {
    _0x574d54 += String.fromCharCode(
      _0x50d89b.charCodeAt(_0x151d1c) ^ _0x1cb155.charCodeAt(_0x151d1c % _0x1cb155.length),
    );
  }
  return _0x574d54;
}
function MyL1IRSfHe(_0xa54f5f) {
  const _0x2b197e = _0xa54f5f.split("").reverse().join("");
  let _0x14fe01 = "";
  for (let _0x1e1913 = 0; _0x1e1913 < _0x2b197e.length; _0x1e1913++) {
    _0x14fe01 += String.fromCharCode(_0x2b197e.charCodeAt(_0x1e1913) - 1);
  }
  let _0x5e7210 = "";
  for (let _0x3f77d8 = 0; _0x3f77d8 < _0x14fe01.length; _0x3f77d8 += 2) {
    _0x5e7210 += String.fromCharCode(parseInt(_0x14fe01.substr(_0x3f77d8, 2), 16));
  }
  return _0x5e7210;
}
function detdj7JHiK(_0x46ddbf) {
  const _0x4fd99c = _0x46ddbf.slice(10, -16);
  const _0x1effe6 = "3SAY~#%Y(V%>5d/Yg\"$G[Lh1rK4a;7ok";
  const _0x411fd5 = atob(_0x4fd99c);
  const _0x1b9ca3 = _0x1effe6.repeat(Math.ceil(_0x411fd5.length / _0x1effe6.length)).substring(0, _0x411fd5.length);
  let _0x5062ac = "";
  for (let _0x47adac = 0; _0x47adac < _0x411fd5.length; _0x47adac++) {
    _0x5062ac += String.fromCharCode(_0x411fd5.charCodeAt(_0x47adac) ^ _0x1b9ca3.charCodeAt(_0x47adac));
  }
  return _0x5062ac;
}
function nZlUnj2VSo(_0x132a77) {
  var _0x4577d0 = {
    x: "a",
    y: "b",
    z: "c",
    a: "d",
    b: "e",
    c: "f",
    d: "g",
    e: "h",
    f: "i",
    g: "j",
    h: "k",
    i: "l",
    j: "m",
    k: "n",
    l: "o",
    m: "p",
    n: "q",
    o: "r",
    p: "s",
    q: "t",
    r: "u",
    s: "v",
    t: "w",
    u: "x",
    v: "y",
    w: "z",
    X: "A",
    Y: "B",
    Z: "C",
    A: "D",
    B: "E",
    C: "F",
    D: "G",
    E: "H",
    F: "I",
    G: "J",
    H: "K",
    I: "L",
    J: "M",
    K: "N",
    L: "O",
    M: "P",
    N: "Q",
    O: "R",
    P: "S",
    Q: "T",
    R: "U",
    S: "V",
    T: "W",
    U: "X",
    V: "Y",
    W: "Z",
  };
  return _0x132a77.replace(/[xyzabcdefghijklmnopqrstuvwXYZABCDEFGHIJKLMNOPQRSTUVW]/g, function(_0x27b05f) {
    return _0x4577d0[_0x27b05f];
  });
}
function laM1dAi3vO(_0x247af1) {
  const _0x3abc86 = _0x247af1.split("").reverse().join("");
  const _0x4334b0 = _0x3abc86.replace(/-/g, "+").replace(/_/g, "/");
  const _0xaf1d09 = atob(_0x4334b0);
  let _0x13c192 = "";
  const _0x2ed430 = 5;
  for (let _0x19e58b = 0; _0x19e58b < _0xaf1d09.length; _0x19e58b++) {
    _0x13c192 += String.fromCharCode(_0xaf1d09.charCodeAt(_0x19e58b) - _0x2ed430);
  }
  return _0x13c192;
}
function GuxKGDsA2T(_0x23be91) {
  const _0x3b7914 = _0x23be91.split("").reverse().join("");
  const _0x434653 = _0x3b7914.replace(/-/g, "+").replace(/_/g, "/");
  const _0x55c940 = atob(_0x434653);
  let _0x4a190a = "";
  const _0x1ccb32 = 7;
  for (let _0x450745 = 0; _0x450745 < _0x55c940.length; _0x450745++) {
    _0x4a190a += String.fromCharCode(_0x55c940.charCodeAt(_0x450745) - _0x1ccb32);
  }
  return _0x4a190a;
}
function LXVUMCoAHJ(_0xe2f470) {
  const _0x4c0c8b = _0xe2f470.split("").reverse().join("");
  const _0x4964d2 = _0x4c0c8b.replace(/-/g, "+").replace(/_/g, "/");
  const _0x419a20 = atob(_0x4964d2);
  let _0x3239f9 = "";
  const _0x40d343 = 3;
  for (let _0x2b1dfe = 0; _0x2b1dfe < _0x419a20.length; _0x2b1dfe++) {
    _0x3239f9 += String.fromCharCode(_0x419a20.charCodeAt(_0x2b1dfe) - _0x40d343);
  }
  return _0x3239f9;
}
export function decrypt(param, type) {
  console.log("decrypt", `param: "${param}", type: "${type}"`);
  switch (type) {
    case "LXVUMCoAHJ":
      return LXVUMCoAHJ(param);
    case "GuxKGDsA2T":
      return GuxKGDsA2T(param);
    case "laM1dAi3vO":
      return laM1dAi3vO(param);
    case "nZlUnj2VSo":
      return nZlUnj2VSo(param);
    case "Iry9MQXnLs":
      return Iry9MQXnLs(param);
    case "IGLImMhWrI":
      return IGLImMhWrI(param);
    case "GTAxQyTyBx":
      return GTAxQyTyBx(param);
    case "C66jPHx8qu":
      return C66jPHx8qu(param);
    case "MyL1IRSfHe":
      return MyL1IRSfHe(param);
    case "detdj7JHiK":
      return detdj7JHiK(param);
    case "SqmOaLsKHv7vWtli":
      return SqmOaLsKHv7vWtli(param);
    case "bMGyx71TzQLfdonN":
      return bMGyx71TzQLfdonN(param);
    default:
      return null;
  }
}
